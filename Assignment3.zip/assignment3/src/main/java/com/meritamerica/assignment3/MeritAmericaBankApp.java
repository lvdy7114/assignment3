package com.meritamerica.assignment3;

public class MeritAmericaBankApp {
	public static void main(String[] args) {
		
		
		BankAccount checkingAccount = new BankAccount();
		checkingAccount.withdrawal(100);
		checkingAccount.deposit(50);
		System.out.println(checkingAccount.getBalance());
	}
}