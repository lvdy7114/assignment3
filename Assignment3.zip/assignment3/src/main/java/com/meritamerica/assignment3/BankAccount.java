package com.meritamerica.assignment3;

import java.util.*;

public class BankAccount {

	//fields
	private double balance;
	private double interestRate = 0.0001;
	private Date dateAndTime;
	private long accountNumber;
	private double futureValue;
	private int year;
	boolean withdraw;
	boolean deposit;
	
	
	//withdraw and deposit boolean
	public void deposit(double depositAmount) {
		this.balance += depositAmount;
		System.out.println("Deposit of " +depositAmount + " made. New balance is " + this.balance);
	}
	
	public void withdrawal (double withdrawal) {
		if(this.balance - withdrawal < 0 ) {
			System.out.println("Only " + this.balance + " available. Withdrawal not processed");
		} else {
			this.balance -= withdrawal;
			System.out.println("Withdrawal of " + withdrawal + "processed. Remaining balance = " + this.balance);
		}
	}
	
	//date and time
	public void DateAndTimeObject() {
		dateAndTime = Calendar.getInstance().getTime();
	}
	public Date getDateAndTime() {
		return dateAndTime;
	}
	
	public BankAccount() {
		this.balance = 0;
		
	}
	//constructor 
	public BankAccount(double balance, double interestRate, Date dateAndTime, long accountNumber, double futureValue,
			int year) {
		super();
		this.balance = balance;
		this.interestRate = interestRate;
		this.dateAndTime = dateAndTime;
		this.accountNumber = accountNumber;
		this.futureValue = futureValue;
		this.year = year;
		
	}
	
	//get and set
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getFutureValue() {
		return futureValue;
	}
	public void setFutureValue(double futureValue) {
		this.futureValue = futureValue;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setDateAndTime(Date dateAndTime) {
		this.dateAndTime = dateAndTime;
	}
	
	//boolean
	
	
	
}
