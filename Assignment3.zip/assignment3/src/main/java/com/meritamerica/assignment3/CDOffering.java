package com.meritamerica.assignment3;

public class CDOffering {

    static int term;
    static double InterestRate;

	
	//Constructor
    
	public  CDOffering(int term, double interestRate) {
		this.term= term;
		this.InterestRate= interestRate;
	}
	
	public int getTerm() {
		return term;
		
	}
	
	public double getInterestRate() {
		return InterestRate;
	}
	
		
}
